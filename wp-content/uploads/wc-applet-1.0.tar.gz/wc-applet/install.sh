#!/bin/bash
cp -v wc-applet.py  /usr/local/bin
cp -v windows_counter.server /usr/lib/bonobo/servers/

