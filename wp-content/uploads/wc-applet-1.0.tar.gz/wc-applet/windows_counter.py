#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import wnck

def main():
    screen = wnck.screen_get_default()
    screen.force_update()
    olist = screen.get_windows_stacked()
    wlist = []
    for window in olist:
        wtype = window.get_window_type().value_name
        if wtype == 'WNCK_WINDOW_NORMAL':
            wlist.append(window)
            name =  window.get_name()
            print "%s : %s" % (wtype, name)
    print "En total: %d" % len(wlist)



if __name__ == '__main__':
    main()
