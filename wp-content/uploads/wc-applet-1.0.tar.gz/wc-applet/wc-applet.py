#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Copyright (c) 2008 by ant30
#
# Generated: Mon Jun 23 21:33:55 2008
# Generator: wc-applet.py
#
# GNU General Public Licence (GPL)
# 
# This program is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation; either version 2 of the License, or (at your option) any later
# version.
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
# details.
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA  02111-1307  USA
#
# Simple skeleton for Python powered GNOME applet
# Skeleton provided by Pythy <the.pythy@gmail.com>





import pygtk
pygtk.require('2.0')

import sys

import gtk
import gnome.ui
import gnomeapplet
import gobject

import wnck


class WcApplet(gnomeapplet.Applet):
    """Simple Windows Opened Counter Applet"""

    def __init__(self, applet, iid):
        """Create applet for proxy"""
        self.timeout_interval = 100
        self.applet = applet
        self.__init_core_widgets()
        self.init_additional_widgets()
        self.init_ppmenu()
        self.__connect_events()
        self.applet.connect("destroy", self._cleanup)
        self.after_init()
        self.applet.show_all()

    def __init_core_widgets(self):
        """Create internal widgets"""
        # making internal widgets
        self.tooltips = gtk.Tooltips()
        self.hbox = gtk.HBox()
        self.ev_box = gtk.EventBox()
        # making widgets' ierarchy
        self.applet.add(self.hbox)
        self.hbox.add(self.ev_box)

    def init_additional_widgets(self):
        """Create additional widgets"""
        self.label = gtk.Label("wc: " + str(len(self.windows_counter())))
        self.ev_box.add(self.label)
        gobject.timeout_add(self.timeout_interval,self.timeout_callback, self)

    def init_ppmenu(self):
        """Create popup menu for properties"""
        self.ppmenu_xml = """
        <popup name="button3">
        <menuitem name="About Item" verb="About" stockid="gtk-about"/>
        </popup>        
        """
        self.ppmenu_verbs = [("About", self.on_ppm_about),
            ]

    def __connect_events(self):
        """Connect applet's events to callbacks"""
        self.ev_box.connect("button-press-event", self.on_button)
        self.ev_box.connect("enter-notify-event", self.on_enter)
        self.button_actions = {
            1: lambda: None,
            2: lambda: None,
            3: self._show_ppmenu,
            }

    def after_init(self):
        """After-init hook"""
        pass

    def _cleanup(self, event):
        """Cleanup callback (on destroy)"""
        del self.applet

    def on_button(self, widget, event):
        """Action on pressing button in applet"""
        if event.type == gtk.gdk.BUTTON_PRESS:
            self.button_actions[event.button]()

    def _show_ppmenu(self):
        """Show popup menu"""
        print self.applet.setup_menu.__doc__
        self.applet.setup_menu(self.ppmenu_xml,
                               self.ppmenu_verbs,
                               None)

    def on_enter(self, widget, event):
        """Action on entering mouse to widget"""
        info = "Hey, you have got %d opened windows" % len(self.windows_counter())
        self.tooltips.set_tip(self.ev_box, info)

    def on_ppm_about(self, event, data=None):
        """Action on chose 'about' in pop-up menu"""
        about = gnome.ui.About("Windows Counter", "1.0" ,"GPL v2", 
                "Applet to count all opened windows on all desktops",
                [u"Antonio Pérez-Aranda Alcaide <ant30tx@gmail.com>"],
                (u"Antonio Pérez-Aranda Alcaide <ant30tx@gmail.com>",))
        about.show()

    def windows_counter(self):
        screen = wnck.screen_get_default()
        screen.force_update()
        olist = screen.get_windows_stacked()
        wlist = [ window.get_name() \
                  for window in olist \
                  if window.get_window_type().value_name == 'WNCK_WINDOW_NORMAL' ]
        return wlist 
        
    def timeout_callback(self, event):
        """Action on timeout """
        wc = len(self.windows_counter())
        self.label.set_text("wc: " + str(wc))
        gobject.timeout_add(self.timeout_interval,self.timeout_callback, self)       

    

def applet_factory(applet, iid):
    WcApplet(applet, iid)
    return True

def run_in_panel():
   gnomeapplet.bonobo_factory('OAFIID:GNOME_WCApplet_Factory',
                             gnomeapplet.Applet.__gtype__,
                             'Window Counter', '1.0', applet_factory)


def run_in_window():
    main_window = gtk.Window(gtk.WINDOW_TOPLEVEL)
    main_window.set_title("WC Applet")
    main_window.connect("destroy", gtk.main_quit)
    app = gnomeapplet.Applet()
    applet_factory(app, None)
    app.reparent(main_window)
    main_window.show_all()
    gtk.main()
    sys.exit()

def main(args):
    if len(args) == 2 and args[1] == "run-in-window":
        run_in_window()
    else:
        run_in_panel()

if __name__ == '__main__':
    main(sys.argv)
