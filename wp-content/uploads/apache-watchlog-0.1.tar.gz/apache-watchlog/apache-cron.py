#!/usr/bin/python2.4
#


"""
"""

MARK_LAST_TIME_PATH = '/home/aperezaranda/src/apache-watchlog/last_log_line'
LOGPATH = '/home/aperezaranda/src/apache-watchlog/example.log'
OSCOMMAND= 'echo comando de prueba'
ERROR_MESSAGE="exit signal Segmentation fault"

import string
import sys, re, time, os
from exceptions import IOError
from optparse import OptionParser

def get_last_view_log():
    filename = MARK_LAST_TIME_PATH
    try:
        fichero = open(filename)
    except IOError:
        return None
    linea = fichero.readline()
    fichero.close()
    return linea


def set_last_view_log(line):
    filename = MARK_LAST_TIME_PATH
    try:
        fichero = open(filename, 'w')
    except IOError:
        return None
    fichero.write(line)
    fichero.close()


def printError(error):
    sys.stderr.write('\n***********\n' + error + '\n***********\n\n')



def reviseParams(params):
    if params.filelog:
        LOGPATH=params.filelog
        MARK_LAST_TIME_PAT=params.filelog + '.last_log_line'


def read_last_log_line():
    try:
        filelog = open(LOGPATH, 'r')
    except IOError:
        printError("ERROR: can't open the file " + filename )
        filelog = None
        return None

    if filelog:
        lines = filelog.readlines()
        filelog.close()
        return lines[-1]


######################## Script
def script(params):

    reviseParams(params)

    last_log_line = read_last_log_line()
   
    last_revise_line = get_last_view_log()

    if last_log_line == last_revise_line:
        return

    if re.search(ERROR_MESSAGE, last_log_line):
        set_last_view_log(last_log_line)
        print "executing: %s" % OSCOMMAND
        os.system(OSCOMMAND)
    



def __main__():

    options={
         'filelog': {'short':'-f', 'large': '--filelog', 'help': "--filelog=path  (-f log) path to the filelog "},
    }

    parser = OptionParser()
    for op in options:
        parser.add_option(options[op]['short'], options[op]['large'], dest=op, help=options[op]['help'])

    (params, args) = parser.parse_args()

    script(params)
    sys.exit(0)

if __name__ == '__main__':
    __main__()




